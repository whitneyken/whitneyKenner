﻿using System;
namespace LMS.Enums
{
	public enum Roles
	{
		Administrator,
		Professor,
		Student
	}
}

