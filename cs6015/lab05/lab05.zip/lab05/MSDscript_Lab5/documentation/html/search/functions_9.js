var searchData=
[
  ['variable_0',['Variable',['../class_variable.html#a6e75e78cee3e6b9e716a225c4021be02',1,'Variable']]]
];
