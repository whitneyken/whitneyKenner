var searchData=
[
  ['variable_0',['Variable',['../class_variable.html',1,'']]]
];
