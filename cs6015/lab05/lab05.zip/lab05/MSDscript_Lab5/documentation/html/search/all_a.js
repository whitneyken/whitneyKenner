var searchData=
[
  ['subst_0',['subst',['../class_num.html#a7ad0384b90b5937a4be1b499d0d028b3',1,'Num::subst()'],['../class_add.html#a5c27f7f5af69b902b132b8bece1c9a5c',1,'Add::subst()'],['../class_mult.html#a36344eaa03e35791c98403e4ddc27d84',1,'Mult::subst()'],['../class_variable.html#a80bf8ca5d6873a3734701b598e94c31f',1,'Variable::subst()']]]
];
