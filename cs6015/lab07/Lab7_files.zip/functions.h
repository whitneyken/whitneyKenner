#include <iostream>
#include <string>
using namespace std;

bool search1 ( string a[], int size, string key);

bool search2 ( string a[], int size, string key);

void sort1(string a[], int n);

void sort2(string a[], int n);

string min(string x, string y);

void sort3_helper(string input[], int left, int right, string scratch[]);

int sort3(string input[], int size);


