
console.log("Hello World");

let national_parks = [];
window.onload = async function() {
  try{
  let text = await d3.text("output.json");
  for(let line of text.split('\n')){
    if(line){
      let obj = JSON.parse(line);
      console.log(obj["index"])
      national_parks.push(line["index"]);
    }
  }
}catch (error) {
    console.error("Error parsing JSON:", error);
  }

}
