
console.log("I changed this");

let national_parks = [];
let usStatesData;
let featuresArr = [];
window.onload = async function() {
  let text = await d3.text("output.json");
  let usData = await d3.json("us.json");
  featuresArr = usData.features;
  console.log(featuresArr);


  for(let line of text.split('\n')){
    if(line){
      let obj = JSON.parse(line);
      //console.log(obj["index"])
      for(let park of obj["index"].split(", ")){
        national_parks.push(park);
      }
    }
  }
makeNPList();
makeUSMap();

}


function makeUSMap() {
  let map = d3.select("#map");
  let projection = d3.geoIdentity().fitSize([800, 500], usStatesData);

  let path = d3.geoPath().projection(projection);

  map.selectAll("path")
    .data(featuresArr)
    .enter()
    .append("path")
    .attr("d", path)
    .style("fill", "lightpink")
    .style("stroke", "white")
    .style("stroke-width", 0.5);
}
// function makeUSMap(){
//   //let path = d3.geoPath();
//   let map = d3.select("#map");
//   let projection = d3.geoAlbersUsa()
//     .fitSize([800, 500], {type:"featureCollection", features: []});
//
//   let path = d3.geoPath().projection(projection);
//
//   d3.json(usStatesData).then(function(data){
//     let featureCollection = d3.geoJson(data);
//     map.selectAll("path")
//     .data(featuresArr)
//     .enter()
//     .append("path")
//     .attr("d", path)
//     .style("fill", "lightpink")
//     .style("stroke", "white")
//     .style("stroke-width", 0.5)
//   });
//}
function makeNPList(){
  let npNameDiv = d3.select("#npNameDiv");
  npNameDiv.selectAll('p')
    .data(national_parks)
    .join(
      enter => {
        enter.append('p')
        .text( (d, i)=> d)
        .on("click", handleNPClick)
      }
    );

}//end make NP list

function handleNPClick(event, data){
  //this <- DOM element
  let elem = d3.select(this);
  //getter
  let currentState = elem.classed("selected");
  //setter
  elem.classed("selected", !currentState);
}
