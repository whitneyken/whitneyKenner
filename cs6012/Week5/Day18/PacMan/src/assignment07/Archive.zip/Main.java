package assignment07;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {

        PathFinder.solveMaze("mazes/bigMaze.txt", "tiny.txt");

    }
}