package assignment03;

public class Squid {
    private String name_;
    public int numTentacles_;
    public int IQ_;

    Squid(int iq, int numTentacles, String name){
        name_ = name;
        IQ_ = iq;
        numTentacles_ = numTentacles;
    }
}
