#include <iostream>
#include <unistd.h>
#include "string"


int main(int argc, char **argv) {
    int fds[2];
    int size = 0;

    //handling if an invalid number of arguments is passed in
    if (argc == 1) {
        std::cout << "invalid number of arguments" << std::endl;
        exit(1);
    }

    //initializing the pipe and checking for failure
    if (pipe(fds) < 0) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    //syscall to fork
    pid_t child_pid = fork();
    //checking for forking failure
    if (child_pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (child_pid > 0) {
        std::cout << "parent " << getpid() << std::endl;
        size = strlen(argv[1]);
        close(fds[0]);
        write(fds[1], &size, sizeof(size));
        write(fds[1], argv[1], strlen(argv[1]));
        //could also use wait(nullptr), but this will wait for multiple children to stop, not a specific one
        waitpid(child_pid, nullptr, 0);
        close(fds[1]);
    } else {
        close(fds[1]);
        //read from the pipe, first to get the string length and then to get teh string
        read(fds[0], &size,
             sizeof(size));
        char string[size];
        read(fds[0], string, size
        );
        close(fds[0]);
        std::cout << "child " << getpid() << std::endl;
        std::cout << "the passed in message is: " << string << " the number of chars in this word is: "
                  << sizeof(string) << std::endl;
        std::exit(0);
    }

    return 0;
}
