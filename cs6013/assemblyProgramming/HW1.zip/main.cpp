extern "C" {
void sayHello();
void myPuts();
}

int main(){
myPuts();
}
